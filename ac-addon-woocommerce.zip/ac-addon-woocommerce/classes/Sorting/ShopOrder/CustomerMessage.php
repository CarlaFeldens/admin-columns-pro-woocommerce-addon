<?php

namespace ACA\WC\Sorting\ShopOrder;

use ACP;

class CustomerMessage extends ACP\Sorting\Model {

	public function get_sorting_vars() {
		$ids = [];

		foreach ( $this->strategy->get_results() as $id ) {
			$ids[ $id ] = $this->get_message( $id );
		}

		return [
			'ids' => $this->sort( $ids ),
		];
	}

	private function get_message( $id ) {
		$order = wc_get_order( $id );

		return $order->get_customer_note();
	}

}