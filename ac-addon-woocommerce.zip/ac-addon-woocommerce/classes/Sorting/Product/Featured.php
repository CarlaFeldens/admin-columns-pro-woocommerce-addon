<?php

namespace ACA\WC\Sorting\Product;

use ACA\WC\Column;
use ACP;
use WC_Product_Data_Store_CPT;

/**
 * @property Column\Product\Featured $column
 */
class Featured extends ACP\Sorting\Model {

	public function __construct( $column ) {
		parent::__construct( $column );

	}

	public function get_sorting_vars() {
		$wc_products = new WC_Product_Data_Store_CPT();

		$featured_items = array_keys( $wc_products->get_featured_product_ids() );
		$not_featured_items = get_posts( [
			'post_type'      => [ 'product' ],
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'fields'         => 'ids',
			'post__not_in'   => $featured_items,
		] );

		$ids = array_merge( $featured_items, $not_featured_items );

		if ( 'DESC' === $this->get_order() ) {
			$ids = array_reverse( $ids );
		}

		return [
			'ids' => $ids,
		];
	}

}