<?php

namespace ACA\WC\Column\ShopCoupon;

use AC;
use ACA\WC\Settings;
use ACP;

class Limit extends AC\Column\Meta
	implements ACP\Sorting\Sortable, ACP\Editing\Editable, ACP\Filtering\Filterable {

	public function __construct() {
		$this->set_type( 'column-shop-coupon_limit' )
		     ->set_label( __( 'Coupon limit', 'codepress-admin-columns' ) )
		     ->set_group( 'woocommerce' );
	}

	public function get_meta_key() {
		return $this->get_setting( 'coupon_limit' )->get_value();
	}

	protected function register_settings() {
		$this->add_setting( new Settings\ShopCoupon\Limit( $this ) );
	}

	public function filtering() {
		$model = new ACP\Filtering\Model\Meta( $this );
		$model->set_data_type( 'numeric' )
		      ->set_ranged( true );

		return $model;
	}

	public function editing() {
		return new ACP\Editing\Model\Meta( $this );
	}

	public function sorting() {
		$model = new ACP\Sorting\Model\Meta( $this );
		$model->set_data_type( 'numeric' );

		return $model;
	}

}