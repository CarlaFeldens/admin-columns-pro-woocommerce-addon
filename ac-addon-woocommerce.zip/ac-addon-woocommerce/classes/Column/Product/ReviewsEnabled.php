<?php

namespace ACA\WC\Column\Product;

use AC;
use ACA\WC\Editing;
use ACA\WC\Filtering;
use ACA\WC\Search;
use ACA\WC\Sorting;
use ACP;

/**
 * @since 1.0
 */
class ReviewsEnabled extends AC\Column
	implements ACP\Sorting\Sortable, ACP\Editing\Editable, ACP\Filtering\Filterable, ACP\Search\Searchable {

	public function __construct() {
		$this->set_type( 'column-wc-reviews_enabled' );
		$this->set_label( __( 'Reviews Enabled', 'codepress-admin-columns' ) );
		$this->set_group( 'woocommerce' );
	}

	// Display

	public function get_value( $id ) {
		return ac_helper()->icon->yes_or_no( 'open' === $this->get_raw_value( $id ) );
	}

	public function get_raw_value( $id ) {
		return $this->get_comment_status( $id );
	}

	// Pro

	public function filtering() {
		return new Filtering\Product\ReviewsEnabled( $this );
	}

	public function editing() {
		return new Editing\Product\ReviewsEnabled( $this );
	}

	public function sorting() {
		return new ACP\Sorting\Model( $this );
	}

	public function search() {
		return new Search\Product\ReviewsEnabled();
	}

	public function is_valid() {
		return post_type_supports( $this->get_post_type(), 'comments' );
	}

	// Common

	private function get_comment_status( $id ) {
		return ac_helper()->post->get_raw_field( 'comment_status', $id );
	}

}